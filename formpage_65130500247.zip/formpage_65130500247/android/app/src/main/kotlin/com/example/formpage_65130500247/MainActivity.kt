package com.example.formpage_65130500247

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
