package com.example.multipage_65130500247

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
